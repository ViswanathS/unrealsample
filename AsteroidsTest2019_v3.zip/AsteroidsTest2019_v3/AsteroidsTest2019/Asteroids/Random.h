#ifndef RANDOM_H_INCLUDED
#define RANDOM_H_INCLUDED

class Random
{
public:
	static float GetFloat(float max);
	static float GetFloat(float min, float max);
};

#endif // RANDOM_H_INCLUDED
