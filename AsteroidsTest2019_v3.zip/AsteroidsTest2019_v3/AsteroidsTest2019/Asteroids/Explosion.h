#ifndef EXPLOSION_H_INCLUDED
#define EXPLOSION_H_INCLUDED

#include "GameEntity.h"

class Explosion : public GameEntity
{
public:
private:
};

#endif // EXPLOSION_H_INCLUDED
